from distutils.core import setup

setup(name='eqshelter',
      verson='1.0',
      py_modules=['launcher','mysmtplib','noti','teller','tkFramework'])