from tkFramework import framework
launch = framework()